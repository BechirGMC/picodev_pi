/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectpidev;

import Entities.News;
import Service.ServiceNews;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.net.URL;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javax.imageio.ImageIO;

/**
 * FXML Controller class
 *
 * @author guest
 */
public class DetailsNewsController_1 implements Initializable {

    @FXML
    private Label news;
    @FXML
    private ImageView imagenews;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
     
        
    }
         public void AffichNewsDet2(News n){
        ServiceNews sn = new ServiceNews();
        news.setText(n.getContenu());               
        
        
        String path = n.getURLImg();
        BufferedImage BfImg = null;
        try {
           
            //BfImg = ImageIO.read(new File(path));
           // URL UrlImg = this.getClass().getResource(path);
            BfImg = ImageIO.read(new FileInputStream(path));
            
            
            
            
        } catch (Exception ex) {
           System.out.println("Failed to load image");
           System.out.println(ex);
        }
        WritableImage wr = null;
        if (BfImg != null) {
            wr = new WritableImage(BfImg.getWidth(), BfImg.getHeight());
            PixelWriter pw = wr.getPixelWriter();
            for (int x = 0; x < BfImg.getWidth(); x++) {
                for (int y = 0; y < BfImg.getHeight(); y++) {
                    pw.setArgb(x, y, BfImg.getRGB(x, y));
                }
            }
        }
        //ImageView PreuvIMG = new ImageView(wr);
        imagenews.setImage(wr);
      
    
}}
