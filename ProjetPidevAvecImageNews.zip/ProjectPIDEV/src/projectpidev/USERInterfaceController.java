/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectpidev;

import Entities.News;
import Service.ServiceNews;
import com.jfoenix.controls.JFXButton;
import java.net.URL;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Background;
import javafx.scene.layout.VBox;

/**
 * FXML Controller class
 *
 * @author guest
 */
public class USERInterfaceController implements Initializable {

    @FXML
    private JFXButton btnFoot;
    @FXML
    private JFXButton btnVoley;
    @FXML
    private JFXButton btnRugby;
    @FXML
    private JFXButton btnTennis;
    @FXML
    private JFXButton btnBasket;
    @FXML
    private JFXButton btnHand;
    @FXML
    private TableView<News> NewsTable;
    @FXML
    private TableColumn<News, Date> ColDate;
    @FXML
    private TableColumn<News, String> ColContenu;


    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
                  
//        ServiceNews sn= new ServiceNews();
//         News n = new News();
//            ObservableList<News> listNews = sn.AfficherNews();
//       ColContenu.setCellValueFactory(new PropertyValueFactory<News, String>("Contenu") );
//       ColDate.setCellValueFactory(new PropertyValueFactory<News, Date>("date") );
//    NewsTable.setItems(listNews);
          
    }    
    private void handleClicks(ActionEvent event){
        if (event.getSource() == btnFoot){
              
             
        ServiceNews sn= new ServiceNews();
         News n = new News();
        
                         sn.AfficherNewsParTypeSport("Football");
                         ObservableList<News> listNews = sn.AfficherNews();
    NewsTable.setItems(listNews);
       
      
        }else if (event.getSource() == btnVoley){
            
        }
        else if (event.getSource() == btnRugby){
            
        }
        else if (event.getSource() == btnTennis){
            
        
}else if (event.getSource() == btnBasket){
            
        
}else if (event.getSource() == btnHand){
            
        }
    }

    



       
         
                 
       
    

  
}
        

