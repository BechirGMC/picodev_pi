/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectpidev;

import Entities.News;

/**
 *
 * @author guest
 */
final public class NewsHolder {
    private int newsid;
     private final static NewsHolder INSTANCE = new NewsHolder();
  
  private NewsHolder() {}
 
  
  public static NewsHolder getInstance() {
    return INSTANCE;
  }

    public int getNewsid() {
        return newsid;
    }

    public void setNewsid(int newsid) {
        this.newsid = newsid;
    }
  
  
  
 
}
