/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Entities.News;
import Services.InterfaceServiceNews;
import Utils.MaConnexion;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.image.Image;
import javafx.stage.FileChooser;



/**
 *
 * @author guest
 */

public class ServiceNews implements InterfaceServiceNews {
    private FileInputStream fis;
    private File file;
    Connection cnx;
    public ServiceNews() {
        cnx=MaConnexion.getInstance().getConnection();
    }
    
    @Override
    public void AjouterNews(News n) {
        try {
//            Statement stm =cnx.createStatement();
//            String query="INSERT INTO `news`(`Contenu`, `Titre`,`Date`,`TypeSport`,`ImageNews`) VALUES ("+'"'+n.getContenu()+'"'+","+'"'+n.getTitre()+'"'+","+'"'+n.getDate()+
//                    '"'+","+'"'+n.getTypeSport()+'"'+","+'"'+n.getImagenews()+'"'+")";
           String query="INSERT INTO `news`(`Contenu`, `Titre`,`Date`,`TypeSport`,`ImageNews`) VALUES (?,?,?,?,?)";
        PreparedStatement pst = cnx.prepareStatement(query);
         FileChooser fileChooser = new FileChooser();
           String Contenu=n.getContenu();
           String Titre=n.getTitre();
//           Date Date= java.sql.Date(n.getDate());
           String TypeSport=n.getTypeSport();
          pst.setString(1, n.getContenu());
           pst.setString(2, n.getTitre());
           java.util.Date d1 = new java.util.Date();
            java.sql.Date dateToday = new java.sql.Date(d1.getTime());
           pst.setDate(3,dateToday);
           pst.setString(4, n.getTypeSport());
     
           pst.setString(5, n.getURLImg());
           
            pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceNews.class.getName()).log(Level.SEVERE, null, ex);}
       

        }

    @Override
    public ObservableList<News> AfficherNews() {
        
         ObservableList<News> news = FXCollections.observableArrayList();

        try {
            Statement stm =cnx.createStatement();
            String query="select * from `news`";
//SELECT * FROM `news` n INNER JOIN `commentaire` c ON n.id=c.idNews
//                   String query="SELECT * FROM `news` n INNER JOIN `commentaire` c ON "+news
            ResultSet rst =stm.executeQuery(query);
            while (rst.next())
            {
                News n = new News();
               n.setId(rst.getInt("id"));
              n.setDate(rst.getDate("date"));
            n.setTitre((rst.getString("Titre")));
                n.setContenu(rst.getString("Contenu"));
                n.setTypeSport(rst.getString("TypeSport"));
                n.setImage(rst.getBlob("ImageNews"));
                
              news.add(n);
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServiceNews.class.getName()).log(Level.SEVERE, null, ex);
        }
            return news;
    }

    
    public void SupprimerNews(News n) {
        try { 
               String query = "delete from `news` where id ="+n.getId();
        PreparedStatement pst = cnx.prepareStatement(query);
          pst.execute();
      } catch (SQLException ex) {
            Logger.getLogger(ServiceNews.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void ModifierNews(News n) {
        try {
//            String query = "UPDATE `news` SET `Contenu`= '"+n.getContenu()+"',`Titre`='"+n.getTitre()+"',`Date`="+n.getDate()+" WHERE id="+n.getId()+"";
//            String query = "UPDATE `news` SET `Contenu`= '"+n.getContenu()+"',`Titre`='"+n.getTitre()+"',`Date`='"+n.getDate()+"',`TypeSport`='"+n.getTypeSport()+"' WHERE id="+n.getId();
String query = "UPDATE `news` SET `Contenu`=?,`Titre`=?,`Date`=?,`TypeSport`=?, `ImageNews`=? WHERE id=?";

         
            PreparedStatement pst = cnx.prepareStatement(query);
            pst.setString(2,n.getContenu());
            pst.setString(3,n.getTitre());
            java.util.Date d1 = new java.util.Date();
                        java.sql.Date dateToday = new java.sql.Date(d1.getTime());
            pst.setDate(5, dateToday);
            pst.setString(6, n.getTypeSport());
//            fis = new FileInputStream(file);
//           pst.setBinaryStream(4,(InputStream)fis,(int)file.length());
            
            pst.setInt(1, n.getId());
            pst.execute();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceNews.class.getName()).log(Level.SEVERE, null, ex);
//        } catch (FileNotFoundException ex) {
//            Logger.getLogger(ServiceNews.class.getName()).log(Level.SEVERE, null, ex);
//        
        }
        
    }
     public ObservableList<News> AfficherNewsParTypeSport(String TypeSport) {
        
         ObservableList<News> news = FXCollections.observableArrayList();

        try {
            Statement stm =cnx.createStatement();
            String query="select * from `news` where TypeSport= "+'"'+TypeSport+'"';
//SELECT * FROM `news` n INNER JOIN `commentaire` c ON n.id=c.idNews
//                   String query="SELECT * FROM `news` n INNER JOIN `commentaire` c ON "+news
            ResultSet rst =stm.executeQuery(query);
            while (rst.next())
            {News n = new News();
                
               n.setId(rst.getInt("id"));
              n.setDate(rst.getDate("date"));
            n.setTitre((rst.getString("Titre")));
                n.setContenu(rst.getString("Contenu"));
                n.setTypeSport(rst.getString("TypeSport"));
              news.add(n);
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServiceNews.class.getName()).log(Level.SEVERE, null, ex);
        }
            return news;
    }

    
    
}
