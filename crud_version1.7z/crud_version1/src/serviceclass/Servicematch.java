/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serviceclass;

/**
 *
 * @author Bechir
 */
import com.sun.org.apache.xalan.internal.lib.ExsltDatetime;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import service.IServicematch;
import util.Maconnexion;

/**
 *
 * @author Bechir
 */


import entite.Match;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import service.IServicematch;
import util.Maconnexion;

/**
 *
 * @author Bechir
 */
public class Servicematch implements IServicematch{
    Connection cnx;

    public Servicematch() {
         cnx=Maconnexion.getInstance().getConnection();
    }
    
    
    
    @Override
    public void ajouter_match(Match m) {
       
      try {
            String requete = "INSERT INTO `match`( `equipeA`, `equipeB`, `date`, `tour`) "
                    +"VALUES ('"+m.getEquipeA()+"','"+m.getEquipeB()+"','"+m.getDate()+"','"+m.getTour()+"')";
            Statement st = Maconnexion.getInstance().getConnection().createStatement();
            st.executeUpdate(requete);
            System.out.println("Match ajoutée");
            
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        
        
        
         
    }

    @Override
    public List<Match> affichage_match() {
         
             List <Match> Match =new ArrayList<>();
            
            try {
            String requete = "SELECT * FROM match";
            Statement st = Maconnexion.getInstance().getConnection()
                    .createStatement();
            ResultSet rs =  st.executeQuery(requete);
            while(rs.next()){
               Match m= new Match();
               
               
                m.setEquipeA(rs.getString("equipeA"));
                m.setEquipeB(rs.getString("equipeB"));
                 m.setDate(rs.getString("date"));
                  m.setTour(rs.getString("tour"));
                Match.add(m);
            }
                } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
            return Match;
            
    }
  

    @Override
    public void supprimer_match(Match m) {
        try {
            String requete = "DELETE FROM match where id=?";
            PreparedStatement pst = Maconnexion.getInstance().getConnection()
                    .prepareStatement(requete);
            pst.setInt(1, m.getId());
            pst.executeUpdate();
            System.out.println("Match supprimée");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        
    }
    @Override
  public void updatematch(Match m) {

                 /*try {
            String requete = "UPDATE `match` SET `id`=[value-1],`equipeA`=[value-2],`equipeB`=[value-3],`date`=[value-4],`tour`=[value-5] WHERE 1";
            PreparedStatement pst = Maconnexion.getInstance().getConnection()
                    .prepareStatement(requete);
            pst.setString(2, m.getEquipeA());
            pst.setString(3, m.getEquipeB());
            pst.setString(4, m.getDate());
            pst.setString(5, m.getTour());
            pst.setInt(1, m.getId());
            pst.executeUpdate();
                     System.out.println("match modifié");
} catch (SQLException ex) {
            System.out.println(ex.getMessage());*/
  }
        
  


    
    
    
    
    
    
    
    
    
}
