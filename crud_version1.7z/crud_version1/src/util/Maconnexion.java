/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import entite.Match;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import entite.Participant;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Bechir
 */
public class Maconnexion {
    final static String URL= "jdbc:mysql://127.0.0.1:3306/pi";
    final static String LOGIN="root";
    final static String PWD="";
    static Maconnexion instance=null;
    private Connection cnx;
    private Maconnexion(){
        try {
            cnx=DriverManager.getConnection(URL,LOGIN,PWD);
             System.out.println("connection etablie");
            
        } catch (SQLException ex) {
            System.out.println("PS DE CPONNEXION");
        }
        
    }
    
public static Maconnexion getInstance(){
    
   if (instance==null){instance =new Maconnexion() ;
      
   }return instance;
           }
public Connection getConnection(){
    return cnx;
}



public static ObservableList<Participant> getDataParticipant()
    {
       
        ObservableList<Participant> list=FXCollections.observableArrayList();
   try{String requete = "select * from participant";
            PreparedStatement ps = Maconnexion.getInstance().getConnection()
                    .prepareStatement(requete);
   
       ResultSet rs=ps.executeQuery();
       while (rs.next()) {
list.add(new Participant(rs.getInt("id"), rs.getString("nom"),rs.getString("prenom")));
       }
   
   }catch (SQLException e){ System.out.println("non liste participant");}
       
        return list;
    }
   



public static Match getmatch(int id) {
        Match m=new Match();
        
                 try {        String requete="select * from match where id=?";

            PreparedStatement pst = Maconnexion.getInstance().getConnection()
                    .prepareStatement(requete);
           pst.setInt(1, id);
           ResultSet rst=pst.executeQuery();
           if(rst.next()){
             pst.setString(2, m.getEquipeA());
         
  pst.setInt(1, m.getId());
            pst.setString(3, m.getEquipeB());
            pst.setString(4, m.getDate());
            pst.setString(5, m.getTour());
           }
            System.out.println("match modifiée");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
                              }
        return m;
        
    }


    
   public static ObservableList<Match> getDatamatch()
    {
       
        ObservableList<Match > list=FXCollections.observableArrayList();
   try{String requete = "SELECT * FROM `match` WHERE 1";
            PreparedStatement ps = Maconnexion.getInstance().getConnection()
                    .prepareStatement(requete);
   
       ResultSet rs=ps.executeQuery();
       while (rs.next()) {
list.add(new Match(rs.getInt("id"), rs.getString("equipeA"),rs.getString("equipeB"),rs.getString("date"),rs.getString("tour") ));
       }
   
   }catch (SQLException e){ System.out.println(e.getMessage());}
       
        return list;
    }
   
    
 public static Participant getParticipantID(int id) {
        Participant e=new Participant();
        
                 try {        String requete="select * from participant where id=?";

            PreparedStatement pst = Maconnexion.getInstance().getConnection()
                    .prepareStatement(requete);
           pst.setInt(1, id);
           ResultSet rst=pst.executeQuery();
           if(rst.next()){
             pst.setString(1, e.getNom());
         
  pst.setInt(2, e.getId());
            pst.setString(3, e.getPrenom());
           }
            System.out.println("participant  modifiée");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
                              }
        return e;
        
    }
    
    
       
    
    
       }


    


