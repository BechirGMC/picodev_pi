/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entite;

/**
 *
 * @author Bechir
 */
public class Match {
    private int id;
    private String equipeA,equipeB;
    private String date;
    private String tour;

    public int getId() {
        return id;
    }

    public String getEquipeA() {
        return equipeA;
    }

    public String getEquipeB() {
        return equipeB;
    }

    public String getDate() {
        return date;
    }

    public String getTour() {
        return tour;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setEquipeA(String equipeA) {
        this.equipeA = equipeA;
    }

    public void setEquipeB(String equipeB) {
        this.equipeB = equipeB;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setTour(String tour) {
        this.tour = tour;
    }

    public Match() {
    }

    public Match(int id, String EquipeA, String equipeB, String date, String tour) {
        this.id = id;
        this.equipeA = EquipeA;
        this.equipeB = equipeB;
        this.date = date;
        this.tour = tour;
    }

    
    
    
    
    
    
    
    
}
