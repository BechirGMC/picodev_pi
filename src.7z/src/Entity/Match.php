<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Match
 *
 * @ORM\Table(name="match")
 * @ORM\Entity
 */
class Match
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="equipeA", type="string", length=20, nullable=false)
     */
    private $equipea;

    /**
     * @var string
     *
     * @ORM\Column(name="equipeB", type="string", length=20, nullable=false)
     */
    private $equipeb;

    /**
     * @var string
     *
     * @ORM\Column(name="tour", type="string", length=20, nullable=false)
     */
    private $tour;

    /**
     * @var string
     *
     * @ORM\Column(name="date", type="string", length=50, nullable=false)
     */
    private $date;


}
