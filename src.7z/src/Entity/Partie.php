<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Partie
 *
 * @ORM\Table(name="partie")
 * @ORM\Entity
 */
class Partie
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;


    /**
     * @var string
     * @Assert\NotBlank (message="champ obligatoire")
     * @ORM\Column(name="equipeA", type="string", length=20, nullable=false)
     */
    private $equipea;

    /**
     * @var string
     * @Assert\NotBlank (message="champs obligatoire")
     * @ORM\Column(name="equipeB", type="string", length=20, nullable=false)
     */
    private $equipeb;

    /**
     * @var string
     * @Assert\NotBlank (message="champs obligatoire")
     * @ORM\Column(name="tour", type="string", length=20, nullable=false)
     */
    private $tour;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date", type="date", nullable=false)
     */
    private $date;

    /**
     * Partie constructor.
     */



    /**
     * @return int
     */
    public function getId(): ? int
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getEquipea():? string
    {
        return $this->equipea;
    }

    /**
     * @return string
     */
    public function getEquipeb(): ?string
    {
        return $this->equipeb;
    }

    /**
     * @return string
     */
    public function getTour(): ?string
    {
        return $this->tour;
    }

    /**
     * @return  \DateTime
     */
    public function getDate(): ?\DateTime
    {
        return $this->date;
    }

    /**
     * @param int $id
     */
    public function setId(int $id): void
    {
        $this->id = $id;
    }

    /**
     * @param string $equipea
     */
    public function setEquipea(string $equipea): void
    {
        $this->equipea = $equipea;
    }

    /**
     * @param string $equipeb
     */
    public function setEquipeb(string $equipeb): void
    {
        $this->equipeb = $equipeb;
    }

    /**
     * @param string $tour
     */
    public function setTour(string $tour): void
    {
        $this->tour = $tour;
    }

    /**
     * @param \DateTime $date
     */
    public function setDate(\DateTime $date): void
    {
        $this->date = $date;
    }


}
