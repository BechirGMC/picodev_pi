<?php




namespace App\Controller;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\Common\Annotations\DocLexer;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use App\Entity\Partie;
use Symfony\Component\Form\Form;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use App\Form\PartieType;
use Symfony\Component\HttpFoundation\Response;
 use Symfony\Component\Form\FormTypeInterface;



class PartieController extends AbstractController
{
    /**
     * @Route("/partie", name="partie")
     */
    public function index(): Response
    {
        return $this->render('partie/index.html.twig', [
            'controller_name' => 'PartieController',
        ]);
    }

    /**
     * @Route("/affichepartie", name="affichepartie")
     */
    public function afficherc(){

        $repository=$this->getdoctrine()->getrepository(Partie::class);
        $parties=$repository->findAll();
        return $this->render('partie/affichepartie.html.twig', [
            'partie'=>$parties,
        ]);
    }


    /**
     * @Route("supp/{id}", name="deletep")
     */
    function Delete($id){
        $partie=$this->getDoctrine()->getRepository(Partie::class)->find($id);
        $em=$this->getDoctrine()->getManager();
        $em->remove($partie);
        $em->flush();
        return $this->redirectToRoute("affichepartie");


    }

    /**
     * @param Request  $request
     *@Route("/partie/add", name="add")
     * @return Response

     */
    function add( Request $request)
    {
        $partie = new Partie();
        $form = $this->createForm(PartieType::class, $partie);
        $form->add('Ajouter', SubmitType::class);
        $form->handleRequest($request);
        if ($form->isSubmitted() &&($form->isValid())) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($partie);
            $em->flush();
            return $this->redirectToRoute('affichepartie');

        }
        return $this->render('partie/addpartie.html.twig', ['form' => $form->createView()
        ]);
    }
    /**
     * @Route ("/update/{id}", name ="update")
     */
    function  Update (Request $request,$id)
    { $partie=$this->getDoctrine()->getRepository(Partie::class)->find($id);
        $form =$this->createForm(PartieType::class,$partie);
        $form->add('update', SubmitType::class

        );
        $form->handleRequest($request);
        if ($form ->isSubmitted() && $form->isValid()){
            $em=$this->getDoctrine()->getManager();
            $em->flush();
            return $this->redirectToRoute('affichepartie');
        }


        return $this->render('partie/updatepartie.html.twig',[
                'form'=>$form->createView()
            ]
        );
    }








    }
