<?php

namespace App\Controller;

use App\Entity\Notification;
use App\Form\NotificationType;
use MercurySeries\FlashyBundle\FlashyNotifier;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class NotificationController extends AbstractController
{
    /**
     * @Route("/notification", name="notification")
     */
    public function index(): Response
    {
        return $this->render('notification/index.html.twig', [
            'controller_name' => 'NotificationController',
        ]);
    }


    /**
     * @Route("/affichen", name="affichen")
     */
    public function afficherc(){

        $repository=$this->getdoctrine()->getrepository(Notification::class);
        $notifications=$repository->findAll();
        return $this->render('Notification/affichen.html.twig', [
            'notification'=>$notifications,

        ]);
    }


    /**
     * @param Request  $request
     *@Route("/notification/add", name="add3")
     * @return Response

     */
    function add( Request $request)
    {
        $notification = new Notification();
        $form = $this->createForm(NotificationType::class, $notification);
        $form->add('Ajouter', SubmitType::class);
        $form->handleRequest($request);
        if ($form->isSubmitted() &&($form->isValid())) {


            $em = $this->getDoctrine()->getManager();
            $em->persist($notification);
            $em->flush();
            return $this->redirectToRoute('affichen');

        }
        return $this->render('notification/add.html.twig', ['form' => $form->createView()
        ]);
    }


















}
