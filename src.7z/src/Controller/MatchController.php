<?php

namespace App\Controller;


use App\Entity\Match;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class MatchController extends AbstractController
{
    /**
     * @Route("/match", name="match")
     */
    public function index(): Response
    {
        return $this->render('match/index.html.twig', [
            'controller_name' => 'MatchController',
        ]);
    }


    /**
     * @Route("/affichem", name="affichem")
     */
    public function afficher(){

        $repository=$this->getdoctrine()->getrepository(Match::class);
        $match=$repository->findAll();
        return $this->render('match/affichem.html.twig', [
            'match'=>$match,
        ]);
    }

    /**
     * @Route("supp/{id}", name="deletep")
     */
    function Delete($id){
        $match=$this->getDoctrine()->getRepository(Match::class)->find($id);
        $em=$this->getDoctrine()->getManager();
        $em->remove($match);
        $em->flush();
        return $this->redirectToRoute("affichem");


    }


}
