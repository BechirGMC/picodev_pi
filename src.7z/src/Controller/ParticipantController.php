<?php

namespace App\Controller;

use App\Entity\Participant;
//use App\participant\ParticopantType;

use App\Form\ParticopantType;
use MercurySeries\FlashyBundle\FlashyNotifier;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\Common\Annotations\DocLexer;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\FormTypeInterface;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Form;
use Dompdf\Dompdf;
use Dompdf\Options;
use App\Form\TextType;
use CalendarBundle\CalendarEvents;
use CalendarBundle\Participant\CalendarEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;




class ParticipantController extends AbstractController
{
    /**
     * @Route("/participant", name="participant")
     */
    public function index(): Response
    {
        return $this->render('participant/index.html.twig', [
            'controller_name' => 'ParticipantController',




        ]);
    }


    /**
     * @Route("/affichep", name="affichep")
     */
    public function afficherc(){

        $repository=$this->getdoctrine()->getrepository(Participant::class);
        $participants=$repository->findAll();
        return $this->render('participant/affichep.html.twig', [
            'participant'=>$participants,

        ]);
    }

    /**
     * @Route("/affichepFront", name="affichepFront")
     */
    public function afficher(){

        $repository=$this->getdoctrine()->getrepository(Participant::class);
        $participants=$repository->findAll();
        return $this->render('participant/affichepFront.html.twig', [
            'participant'=>$participants,

        ]);
    }

    /**
     * @Route("supp/{id}", name="deletem")
     */
function Delete($id){
   $participant=$this->getDoctrine()->getRepository(Participant::class)->find($id);
     $em=$this->getDoctrine()->getManager();
     $em->remove($participant);
     $em->flush();
     return $this->redirectToRoute("affichep");



}

    /**
     * @param Request  $request
    *@Route("/participant/add", name="add2")
     * @return Response

*/
function add( Request $request)
{
    $Participant = new Participant();
    $form = $this->createForm(ParticopantType::class, $Participant);
    $form->add('Ajouter', SubmitType::class);
    $form->handleRequest($request);
    if ($form->isSubmitted() &&($form->isValid())) {


        $em = $this->getDoctrine()->getManager();
        $em->persist($Participant);
        $em->flush();
        return $this->redirectToRoute('affichep');

    }
    return $this->render('participant/add.html.twig', ['form' => $form->createView()
    ]);
}
    /**
     * @Route ("/update/{id}", name ="updatem")
     */
    function  Update (Request $request,$id)
    { $participant=$this->getDoctrine()->getRepository(Participant::class)->find($id);
        $form =$this->createForm(ParticopantType::class,$participant);
        $form->add('update', SubmitType::class

        );
        $form->handleRequest($request);
        if ($form ->isSubmitted() && $form->isValid()){
            $em=$this->getDoctrine()->getManager();
            $em->flush();
            return $this->redirectToRoute('affichep');
        }


        return $this->render('participant/update.html.twig',[
                'form'=>$form->createView()
            ]
        );
    }

    /**
     * @Route("/listp", name="pdf",methods={"GET"})
     */

function listep(){
    $pdfOptions=new Options();
    $pdfOptions->set('defaultFront','Arial');
    $repository=$this->getdoctrine()->getrepository(Participant::class);
      $dompdf=new Dompdf($pdfOptions)  ;
    $participants=$repository->findAll();
    $html= $this->renderView('participant/listp.html.twig' ,['participant'=>$participants,]);
    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4','portrait');
    $dompdf->render();
    $dompdf->stream("participant.pdf",["Attachement=>true"]);



}

    /**
     *  @Route("/stat", name="stat")
     */
 function stat(){

    return $this->render('participant/stat.html.twig');


}



    /**
     *  @Route("/load", name="load")
     */
    function calendar(){

        return $this->render('participant/calendar.html.twig');





    }



    /**

     *  @Route("/about", name="about")
     */

    function about(FlashyNotifier $flashy)
    {
        $flashy->primaryDark('Notification!! a verifier les participants ajouté', 'affichen');
        return $this->render('participant/notif.html.twig');


    }


    /**
     *  @Route("/maps", name="maps")
     */
    function map(){

        return $this->render('participant/maps.html.twig');


    }




}
