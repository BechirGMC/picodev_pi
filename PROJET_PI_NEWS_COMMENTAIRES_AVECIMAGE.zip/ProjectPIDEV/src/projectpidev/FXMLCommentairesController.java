/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectpidev;

import Entities.Commentaire;
import Entities.News;
import Service.ServiceCommentaires;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.time.Instant;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author guest
 */
public class FXMLCommentairesController implements Initializable {

    @FXML
    private TextArea ContenuCommentaire;
    @FXML
    private Label CommentaireAjouté;
    @FXML
    private Button Valider;
    @FXML
    private Button Annuler;
    @FXML
    private Label nblikes;
    @FXML
    private ImageView Likereact;
    @FXML
    private ImageView SolidarityReact;
    @FXML
    private ImageView WouahReact;
    @FXML
    private Button Supprimer;
    @FXML
    private Button Modifier;
    @FXML
    private TableView<Commentaire> tvCommentaires;
    @FXML
    private TableColumn<Commentaire, String> ColContenu;
    @FXML
    private TableColumn<Commentaire, Date> ColDate;
    @FXML
    private TextField id;
    private TableColumn<Commentaire, Integer> Colid;
    @FXML
    private Label nbsolidarityreact;
    @FXML
    private Label nbsWouahreact;
    @FXML
    private Label nbLikereact;
    @FXML
    private TableColumn<?, ?> Colnbreacts;
    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
       ServiceCommentaires sc = new ServiceCommentaires();
        
ShowCommentaires();
        
    }    

    @FXML
    private void ValiderCommentaire(ActionEvent event) {
        ServiceCommentaires sc = new ServiceCommentaires();
        Commentaire c = new Commentaire();
        CommentaireAjouté.setText(ContenuCommentaire.getText());
              
         c.setContenu(CommentaireAjouté.getText());
         java.util.Date d1 = new java.util.Date();
            Date dateToday = new java.sql.Date(d1.getTime());
         c.setDate_dajout(dateToday);
         
         sc.AjouterCommentaire(c,getNewsId());
         ShowCommentaires();
         
    }

    @FXML
    private void AnnulerCommentaire(ActionEvent event) {
        Parent root = null;
        try {
//            root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
            root = FXMLLoader.load(getClass().getResource("USERInterface.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);

            stage.setScene(scene);
            stage.show(); 
            ((Node) (event.getSource())).getScene().getWindow().hide();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

   int n=0;
    int n1=0;
    @FXML
    private void react1(MouseEvent event) {
        
        n1++;
         n++;
       nbLikereact.setText(String.valueOf (n1));
       nblikes.setText(String.valueOf (n));
    }
    int n2=0;
    @FXML
    private void react2(MouseEvent event) {
        
        n2++;
         n++;
       nblikes.setText(String.valueOf (n));
       nbsolidarityreact.setText(String.valueOf (n2));   
    }
    int n3=0;
    @FXML
    private void react3(MouseEvent event) {
            n3++;
         n++;
         nbsWouahreact.setText(String.valueOf (n3));
       nblikes.setText(String.valueOf (n));

   
        
          
    }
    private void AfficherCommentaires(ActionEvent event) throws IOException {
                ServiceCommentaires sc = new ServiceCommentaires();
                ShowCommentaires();
                
    }
                 
        

    @FXML
    private void SupprimerCommentaire(ActionEvent event) {
        ServiceCommentaires sc = new ServiceCommentaires();
            Commentaire c = new Commentaire();
       int IDValue = Integer.parseInt(id.getText());
        c.setId(IDValue);
        sc.SupprimerCommentaire(c);
        ShowCommentaires();
        
    }
    @FXML
     private void ModifierCommentaire(ActionEvent event) {

    ServiceCommentaires sc = new ServiceCommentaires();
        Commentaire c = new Commentaire();
        c.setContenu(ContenuCommentaire.getText());
         java.util.Date d1 = new java.util.Date();
            Date dateToday = new java.sql.Date(d1.getTime());
         c.setDate_dajout(dateToday);
         int IDValue = Integer.parseInt(id.getText());
        c.setId(IDValue);
        sc.ModifierCommentaire(c);
        ShowCommentaires();
   
        
    }
     public void ShowCommentaires(){
        ServiceCommentaires sc = new ServiceCommentaires();
         System.out.println(getNewsId());
        ObservableList<Commentaire> listCommentaires = sc.AfficherCommentaire(getNewsId());
         System.out.println(listCommentaires);
         
       
       ColContenu.setCellValueFactory(new PropertyValueFactory<Commentaire, String>("Contenu") );
       ColDate.setCellValueFactory(new PropertyValueFactory<Commentaire, Date>("dateCommentaire") );
       tvCommentaires.setItems(listCommentaires);
     }

     
     public int getNewsId() {
        NewsHolder holder = NewsHolder.getInstance();
        int t = holder.getNews();
        return t;
    }

    @FXML
    private void AffiageTextArea(MouseEvent event) {
         Commentaire c =tvCommentaires.getSelectionModel().getSelectedItem();
         ContenuCommentaire.setText(c.getContenu());
          String s = String.valueOf(c.getId());
            id.setText(s); 
        
         
           
            ShowCommentaires();
    }
    

    
}

  
    
    

