/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectpidev;

import Entities.News;
import Service.ServiceNews;
import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author guest
 */
public class USERInterfaceController implements Initializable {

    @FXML
    private JFXButton btnFoot;
    @FXML
    private JFXButton btnVoley;
    @FXML
    private JFXButton btnRugby;
    @FXML
    private JFXButton btnTennis;
    @FXML
    private JFXButton btnBasket;
    @FXML
    private JFXButton btnHand;
    @FXML
    private TableView<News> NewsTable;
    @FXML
    private TableColumn<News, Date> ColDate;
    @FXML
    private TableColumn<News, String> ColContenu;


    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        showNews();
          
    }    
    private void handleClicks(ActionEvent event){
        if (event.getSource() == btnFoot){
              
            showNews();
        }else if (event.getSource() == btnVoley){
            
        }
        else if (event.getSource() == btnRugby){
            
        }
        else if (event.getSource() == btnTennis){
            
        
}else if (event.getSource() == btnBasket){
            
        
}else if (event.getSource() == btnHand){
            
        }
    }

    
        public void showNews(){
        ServiceNews sn = new ServiceNews();
        ObservableList<News> listNews = sn.AfficherNews();
        ColContenu.setCellValueFactory(new PropertyValueFactory<News, String>("Contenu") );
       ColDate.setCellValueFactory(new PropertyValueFactory<News, Date>("date") );
       NewsTable.setItems(listNews);
       NewsTable.setRowFactory(tv -> {
            TableRow<News> row = new TableRow<>();
            row.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    if (event.getClickCount() == 2 && (!row.isEmpty())) {
                        News rowData = row.getItem();
                        System.out.println(rowData);
                        Parent root = null;

                        
                        Node node = (Node) event.getSource();
                        Stage stage = (Stage) node.getScene().getWindow();
                        stage.close();
                        try {
                              NewsHolder holder = NewsHolder.getInstance();
                            //System.out.println("id"+rowData.getId());
                            holder.setNews(rowData.getId());
                          //  System.out.println("id"+holder.getNews());
                            root = FXMLLoader.load(USERInterfaceController.this.getClass().getResource("FXMLCommentaires.fxml"));
                          
                            Scene scene = new Scene(root);
                            stage.setScene(scene);
                            stage.show();
                        } catch (IOException ex) {
                         }
                    }
                }
            });
            return row;
        });

        
    }

        
    
     
        @FXML
    private void FootNews(ActionEvent event) {
        
        
        ServiceNews sn= new ServiceNews();
         News n = new News();
        if ( n.getTypeSport()=="Football"){
            showNews();
            
        }
       
         
                 
       
    }
        
}
