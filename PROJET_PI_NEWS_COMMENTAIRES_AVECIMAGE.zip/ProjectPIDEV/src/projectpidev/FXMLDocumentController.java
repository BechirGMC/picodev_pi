/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectpidev;

import Entities.News;
import Service.ServiceNews;
import Utils.MaConnexion;
import java.awt.Desktop;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.sql.Blob;

import java.util.Date;

import java.util.ResourceBundle;
import java.util.function.Predicate;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;

import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;

/**
 *
 * @author guest
 */
public class FXMLDocumentController implements Initializable {
    
    private Label label;
    @FXML
    private ComboBox TypeSport;
    @FXML
    private TextArea Titre;
    @FXML
    private TextArea Contenu;
    @FXML
    private Label AffichageDateTitreContenu;
    @FXML
    private TextField idtodeleteupdate;
    @FXML
    private TableView<News> tvNews;
    @FXML
    private TableColumn<News, Integer> ColId;
    @FXML
    private TableColumn<News, String> ColTitre;
    @FXML
    private TableColumn<News, String> ColContenu;
    @FXML
    private TableColumn<News, Date> ColDate;
    @FXML
    private Button Ajout;
    @FXML
    private TableColumn<News, String> ColTypeSport;
    @FXML
    private TextField Recherche;
    @FXML
    private ImageView imagenews;
    private Image image;
    private File file;
    private Stage stage;
    @FXML
    private AnchorPane anchorPane;
    private FileChooser fileChooser;
    private final Desktop desktop = Desktop.getDesktop();
    @FXML
    private Button imgButton;
    @FXML
    private Button EnvoiButton;
    @FXML
    private TextArea ImgPath;
    
  
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
       
       }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
//        fileChooser = new FileChooser();
//        new FileChooser.ExtensionFilter("Images", "*.png","*.jpg","*.gif");
ServiceNews sn= new ServiceNews();
        News n = new News();
         ObservableList<String> list =FXCollections.observableArrayList
        ("Tennis","Basketball","Football","Volleyball","Baseball","Natation","Rugby");
        
        TypeSport.setItems(list);
        
   
      
       FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(new ExtensionFilter("Image Files","*.png","*.jpg","*.gif"));
      
        imgButton.setOnAction(new EventHandler<ActionEvent>(){
             @Override
             public void handle(ActionEvent event) {
                 file = fileChooser.showOpenDialog(imgButton.getScene().getWindow());
                            
                            ImgPath.setText(file.getAbsolutePath());
                            n.setURLImg(file.getAbsolutePath());

                
             }
         });

         tvNews.setRowFactory(tv -> {
           TableRow<News> row = new TableRow<>();
            row.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    if (event.getClickCount() == 2 && (!row.isEmpty())) {
                        //Reclamation rowData = row.getItem();
                        //System.out.println(rowData);
                       // Parent root = null;

                        News n =tvNews.getSelectionModel().getSelectedItem();
                        Node node = (Node) event.getSource();
                        Stage stage = (Stage) node.getScene().getWindow();
                        
                        FXMLLoader loader = new FXMLLoader ();
                            loader.setLocation(getClass().getResource("DetailsActualites.fxml"));
                        try {
                            loader.load();
                           
                           
                              } catch (IOException ex) {
                            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        DetailsActualitesController RDC = loader.getController();
                        
                        RDC.AffichNewsDet2(n);
                        Parent parent = loader.getRoot();
                        stage.setScene(new Scene(parent));
                        stage.show();
                        
                    }
                }
            }); return row;
                });
           
       showNews1();
      

    
  
    
         
       
                    
    }   

    @FXML
    private void AjouterNews(ActionEvent event) {
//        ServiceNews sn= new ServiceNews();
//        News n = new News();
////        n.setDate(java.sql.Date.valueOf(date.getValue()));
////validate();
//    java.util.Date d1 = new java.util.Date();
//            java.sql.Date dateToday = new java.sql.Date(d1.getTime());
//         n.setDate(dateToday);
//      n.setTitre(Titre.getText());
//        n.setContenu(Contenu.getText());
//        n.setTypeSport(TypeSport.getSelectionModel().getSelectedItem().toString());
//         
//         
//     n.setURLImg(ImgPath.getText());
//       sn.AjouterNews(n);
//        showNews1();
ServiceNews sn= new ServiceNews();
        News n = new News();
//        n.setDate(java.sql.Date.valueOf(date.getValue()));
    java.util.Date d1 = new java.util.Date();
            java.sql.Date dateToday = new java.sql.Date(d1.getTime());
         n.setDate(dateToday);
      n.setTitre(Titre.getText());
        n.setContenu(Contenu.getText());
        n.setTypeSport(TypeSport.getSelectionModel().getSelectedItem().toString());
        n.setURLImg(ImgPath.getText());
        
        sn.AjouterNews(n);
         showNews1(); 
          
       
        


       
         
    }
        //L'affichage des actualités au niveau de la tableview
    private void AfficherNews(ActionEvent eventn ,int n) throws IOException {

                ServiceNews sn= new ServiceNews();
                sn.AfficherNews();
                
                
    }
  
    //Suppression des actualités avec l id correspondant 
    @FXML
    
    private void SupprimerNews(ActionEvent event) {
        
         ServiceNews sn= new ServiceNews();
        News n = new News();
        int IDValue = Integer.parseInt(idtodeleteupdate.getText());
        n.setId(IDValue);
        sn.SupprimerNews(n);
        showNews1();
        
        
    }
       //Modification des actualités 
    @FXML
    private void ModifierNews(ActionEvent event) {

    ServiceNews sn= new ServiceNews();
        News n = new News();
//        n.setDate(java.sql.Date.valueOf(date.getValue()));
            java.util.Date d1 = new java.util.Date();
            java.sql.Date dateToday = new java.sql.Date(d1.getTime());
         n.setDate(dateToday);
      n.setTitre(Titre.getText());
        n.setContenu(Contenu.getText());
        int IDValue = Integer.parseInt(idtodeleteupdate.getText());
        n.setId(IDValue);
//        n.setTypeSport(TypeSport.getSelectionModel().getSelectedItem().toString());
//        n.setImagenews(imagenews.getImage());
        sn.ModifierNews(n);
        showNews1();
  
        
        
    }
    //L'ajout des données de la base de données au niveau des colonnes de la tableview
//    public void showNews(){
//        ServiceNews sn = new ServiceNews();
//        ObservableList<News> listNews = sn.AfficherNews();
//        ColId.setCellValueFactory(new PropertyValueFactory<News, Integer>("id") );
//       ColTitre.setCellValueFactory(new PropertyValueFactory<News, String>("Titre") );
//       ColContenu.setCellValueFactory(new PropertyValueFactory<News, String>("Contenu") );
//       ColDate.setCellValueFactory(new PropertyValueFactory<News, Date>("date") );
//      ColTypeSport.setCellValueFactory(new PropertyValueFactory<News, String>("TypeSport"));
//       tvNews.setItems(listNews);
//       tvNews.setRowFactory(tv -> {
//            TableRow<News> row = new TableRow<>();
//            row.setOnMouseClicked(new EventHandler<MouseEvent>() {
//                @Override
//                public void handle(MouseEvent event) {
//                    if (event.getClickCount() == 2 && (!row.isEmpty())) {
//                        News rowData = row.getItem();
//                        System.out.println(rowData);
//                        Parent root = null;
//
//                        
//                        Node node = (Node) event.getSource();
//                        Stage stage = (Stage) node.getScene().getWindow();
//                        
//                        try {News n = new News();
//                             NewsHolder holder = NewsHolder.getInstance();
//                            //System.out.println("id"+rowData.getId());
//                            holder.setNews(rowData.getId());
//                             n.setTypeSport(TypeSport.getSelectionModel().getSelectedItem().toString());
//                          //  System.out.println("id"+holder.getNews());
//                            root = FXMLLoader.load(FXMLDocumentController.this.getClass().getResource("DetailsNews.fxml"));
//                           
//       sn.AfficherNewsParTypeSport(TypeSport.getSelectionModel().getSelectedItem().toString());
//                            Scene scene = new Scene(root);
//                            stage.setScene(scene);
//                            stage.show();
//                            
//                        } catch (IOException ex) {
//                         }
//                    }
//                }
//            });
//            return row;
//        });
//
//        
//    }
    
        //en cas de clic sur une actualité l id le contenu la date et le type du sport s'affichent au niveau de la zone
        //du texte et une nouvelle interface apparaît pour taper un commentaire
    @FXML
    private void AffichageTextfields(MouseEvent event) throws IOException {
        
//            News n =tvNews.getSelectionModel().getSelectedItem();
//            Titre.setText(n.getTitre());
//            Contenu.setText(n.getContenu());
//            String s = String.valueOf(n.getId());
//            idtodeleteupdate.setText(s);      
            
//            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXMLCommentaires.fxml"));
//            News ne = new News();
//            Parent root1 = (Parent) fxmlLoader.load();
//            Stage stage = new Stage();
//            stage.setScene(new Scene(root1));  
//            stage.show();
//            showNews();


}


    @FXML
    private void Browser(ActionEvent event) {
//        News n = new News();
//        stage = (Stage) anchorPane.getScene().getWindow();
//        file =fileChooser.showOpenDialog(stage);
//        if (file!= null){
//            System.out.println(""+file.getAbsolutePath());
//            image = new Image(file.getAbsoluteFile().toURI().toString());
//           n.setImage(image);
////           file = fileChooser.showOpenDialog(imgButton.getScene().getWindow());
////                            
////                            ImgPath.setText(file.getAbsolutePath());
////                            n.setURLImg(ImgPath.getText());

       
        }
    

    @FXML
    private void AfficherParTypeSpotr(ActionEvent event) {
        ServiceNews sn = new ServiceNews();
        News n = new News();
        n.setTypeSport(TypeSport.getSelectionModel().getSelectedItem().toString());
        sn.AfficherNewsParTypeSport(TypeSport.getSelectionModel().getSelectedItem().toString());
        ObservableList<News> listNews = sn.AfficherNews();
       ColTitre.setCellValueFactory(new PropertyValueFactory<News, String>("Titre") );
       ColContenu.setCellValueFactory(new PropertyValueFactory<News, String>("Contenu") );
       ColDate.setCellValueFactory(new PropertyValueFactory<News, Date>("date") );
       tvNews.setItems(listNews);
       System.out.println(sn.AfficherNewsParTypeSport(TypeSport.getSelectionModel().getSelectedItem().toString()));
        
        
    }

    @FXML
    private void AfficherParTypeSport(ActionEvent event) {
           ServiceNews sn = new ServiceNews();
        News n = new News();
       
//        sn.AfficherNewsParTypeSport(n);
//        ObservableList<News> listNews = sn.AfficherNews();
//       ColTitre.setCellValueFactory(new PropertyValueFactory<News, String>("Titre") );
//       ColContenu.setCellValueFactory(new PropertyValueFactory<News, String>("Contenu") );
//       ColDate.setCellValueFactory(new PropertyValueFactory<News, Date>("date") );
//       tvNews.setItems(listNews);
//      sn.AfficherNewsParTypeSport(n);
//       Parent root = null;
//
//                        
//                        Node node = (Node) event.getSource();
//                        Stage stage = (Stage) node.getScene().getWindow();
//        try {
//            root = FXMLLoader.load(FXMLDocumentController.this.getClass().getResource("DetailsNews.fxml"));
//        } catch (IOException ex) {
//            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
//        }
//                           
//       sn.AfficherNewsParTypeSport(TypeSport.getSelectionModel().getSelectedItem().toString());
//                            Scene scene = new Scene(root);
//                            stage.setScene(scene);
//                            stage.show();
    }
    

    @FXML
    private void AfficherNews(ActionEvent event) {
    }

    @FXML
    private void detailsBouton(ActionEvent event) {
      
         }

    @FXML
    private void Textfieldpressed(KeyEvent event) {
      idtodeleteupdate.textProperty().addListener(new ChangeListener<String>() {
    @Override
    public void changed(ObservableValue<? extends String> observable, String oldValue, 
        String newValue) {
        if (!newValue.matches("\\d*")) {
            idtodeleteupdate.setText(newValue.replaceAll("[^\\d]", ""));
        }
    }

          
    });

        
    }
    public boolean validate(){
         if(Titre.getText().isEmpty() | Contenu.getText().isEmpty() | TypeSport.getSelectionModel().isEmpty() ){
            Alert alert = new Alert(AlertType.WARNING);
            alert.setTitle("Validate Fields");
            alert.setHeaderText(null);
            alert.setContentText("Please enter into the fields");
            alert.showAndWait();
         return false   ;
        }
         return true;
    }
 public void showNews1(){
     ServiceNews sn = new ServiceNews();
        News n = new News();
      ObservableList<News> listNews = sn.AfficherNews();
        ColId.setCellValueFactory(new PropertyValueFactory<News, Integer>("id") );
       ColTitre.setCellValueFactory(new PropertyValueFactory<News, String>("Titre") );
       ColContenu.setCellValueFactory(new PropertyValueFactory<News, String>("Contenu") );
       ColDate.setCellValueFactory(new PropertyValueFactory<News, Date>("date") );
      ColTypeSport.setCellValueFactory(new PropertyValueFactory<News, String>("TypeSport"));
       tvNews.setItems(listNews);}

    @FXML
    private void Search(KeyEvent event) {
        ServiceNews sn = new ServiceNews();
        ObservableList<News> listNews = sn.AfficherNews();
       FilteredList<News> FilteredNews = new FilteredList<>(listNews,e-> true);
        Recherche.textProperty().addListener((Observablevalue,OldValue,NewValue)->{
            FilteredNews.setPredicate((Predicate<? super News>) News ->{
                if (NewValue ==null || NewValue.isEmpty()){
                    return true;
                }
               
                
                String lowerCaseFilter  = NewValue.toLowerCase();
                 
                if(News.getTypeSport().toLowerCase().contains(lowerCaseFilter)){
                    return true;
                }else if(News.getTitre().toLowerCase().contains(lowerCaseFilter)){
                    return true;
                }else if(News.getContenu().toLowerCase().contains(lowerCaseFilter)){
                    return true;
                }else if(String.valueOf(News.getId()).contains(NewValue)){
                    return true;
                }else if(String.valueOf(News.getDate()).contains(NewValue)){
                    return true;
                }
                return false;
                
            });
            SortedList<News> sortedNews = new SortedList<> (FilteredNews);
            sortedNews.comparatorProperty().bind(tvNews.comparatorProperty());
                    tvNews.setItems(sortedNews);
        }
        
        
        );
    
   

    }
    }

    

  
  
  
  


    

    
