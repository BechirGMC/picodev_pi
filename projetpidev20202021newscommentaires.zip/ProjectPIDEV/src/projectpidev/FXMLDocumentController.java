/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectpidev;

import Entities.News;
import Service.ServiceNews;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXListView;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;

import com.twilio.type.PhoneNumber;
import java.awt.Desktop;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import java.net.URL;


import java.util.ResourceBundle;
import java.util.function.Predicate;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;


import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Callback;
import javax.imageio.ImageIO;


/**
 *
 * @author guest
 */
public class FXMLDocumentController implements Initializable {
    
    private Label label;
    @FXML
    private ComboBox TypeSport;
    @FXML
    private TextArea Titre;
    @FXML
    private TextArea Contenu;
    @FXML
    private Label AffichageDateTitreContenu;
    @FXML
    private TextField idtodeleteupdate;

    @FXML
    private Button Ajout;
    @FXML
    private TextField Recherche;
    @FXML
    private ImageView imagenews;
    private Image image;
    private File file;
    private Stage stage;
    @FXML
    private AnchorPane anchorPane;
    private FileChooser fileChooser;
    private final Desktop desktop = Desktop.getDesktop();
    @FXML
    private TextArea ImgPath;
    @FXML
    private Button BoutonAjoutImage;
    @FXML
    private TextArea msg;
    @FXML
    private VBox vBox;
    @FXML
    private JFXListView<News> listView;
   
 
  
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
       
       }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
                AffichList();
                TypeSport.setStyle("  -fx-background-color:#90ee90 ;-fx-selection-bar: #90ee90; ");
        
        fileChooser = new FileChooser();
        new FileChooser.ExtensionFilter("Images", "*.png","*.jpg","*.gif");
ServiceNews sn= new ServiceNews();
        News n = new News();
         ObservableList<String> list =FXCollections.observableArrayList
        ("TENNIS","BASKETBALL","FOOTBALL","VOLLEYBALL","BASEBALL","RUGBY","HANDBALL");
        
        TypeSport.setItems(list);

      BoutonAjoutImage.setOnAction(new EventHandler<ActionEvent>() {
    @Override
    public void handle(ActionEvent event) {
        file = fileChooser.showOpenDialog(BoutonAjoutImage.getScene().getWindow());
        String path = file.getAbsolutePath();
        
        path= path.substring(23, path.length());
        path ="http://localhost/Images/" +path;
        ImgPath.setText(path);
        n.setURLImg(path);
        
       if(file!=null){
            
            try {
                System.out.println(""+file.getAbsolutePath());
                image =new Image(file.getAbsoluteFile().toURL().toString());
               image = new Image(path);
                imagenews.setImage(image);
            } catch(Exception ex)  {
                Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
            }
            

    }}
    });
      
                    
    }   
    
    public static final  String ACCOUNT_SID = "AC5855f26f1d059fcf73911900db0f5647";
    public static final String  AUTH_TOKEN = "6db5b9f5a4fd8d7471fdc4e58f25e042";

    @FXML
    private void AjouterNews(ActionEvent event) {

ServiceNews sn= new ServiceNews();
        News n = new News();
    java.util.Date d1 = new java.util.Date();
            java.sql.Date dateToday = new java.sql.Date(d1.getTime());
         n.setDate(dateToday);
      n.setTitre(Titre.getText());
        n.setContenu(Contenu.getText());
        n.setTypeSport(TypeSport.getSelectionModel().getSelectedItem().toString());
        n.setURLImg(ImgPath.getText());
try{
            Twilio.init(ACCOUNT_SID,AUTH_TOKEN);
            String msgs="un nouvel article a été ajouté, veuillez consulter notre application pour plus de détails";
           
            Message message = Message.creator(new PhoneNumber("+21650660838"),
                    new PhoneNumber("+18649528596"), msg.getText().toString()).create();
        Alert alert = new Alert(AlertType.CONFIRMATION);
            alert.setTitle("Success");
            alert.setHeaderText("");
            alert.setContentText("SMS Send Successfully");
            alert.show(); } catch (Exception e){

    Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Failed");
            alert.setHeaderText("");
            alert.setContentText("Something went wrong:"+e.toString());
            e.printStackTrace();
            alert.show();
        }
        sn.AjouterNews(n);
          AffichList();  
    }
      
        //L'affichage des actualités au niveau de la tableview
    private void AfficherNews(ActionEvent eventn ,int n) throws IOException {

                ServiceNews sn= new ServiceNews();
                sn.AfficherNews();
                
                
                
    }
   
  
    //Suppression des actualités avec l id correspondant 
    @FXML
    private void SupprimerNews(ActionEvent event) {
        
         ServiceNews sn= new ServiceNews();
        News n = new News();
        int IDValue = Integer.parseInt(idtodeleteupdate.getText());
        n.setId(IDValue);
        sn.SupprimerNews(n);
        AffichList();        
        
    }
       //Modification des actualités 
    @FXML
    private void ModifierNews(ActionEvent event) {

    ServiceNews sn= new ServiceNews(); 
        News n = new News();
            java.util.Date d1 = new java.util.Date();
            java.sql.Date dateToday = new java.sql.Date(d1.getTime());
         n.setDate(dateToday);
      n.setTitre(Titre.getText());
        n.setContenu(Contenu.getText());
        int IDValue = Integer.parseInt(idtodeleteupdate.getText());
        n.setId(IDValue);
        n.setURLImg(ImgPath.getText());
        sn.ModifierNews(n);
        AffichList();  
        
        
    }
    
        //en cas de clic sur une actualité l id le contenu la date et le type du sport s'affichent au niveau de la zone
        //du texte et une nouvelle interface apparaît pour taper un commentaire
    @FXML
    private void AffichageTextfields(MouseEvent event) throws IOException {
        
            News n =listView.getSelectionModel().getSelectedItem();
            Titre.setText(n.getTitre());
            Contenu.setText(n.getContenu());
            String s = String.valueOf(n.getId());
            idtodeleteupdate.setText(s);      

            TypeSport.setValue(n.getTypeSport());
            ImgPath.setText(n.getURLImg());

    }

 

          
    
   

    @FXML
    private void Search(KeyEvent event) {
        ServiceNews sn = new ServiceNews();
        ObservableList<News> listNews = sn.AfficherNews();
  
   

    }

    @FXML
    private void ShowStat(ActionEvent event) {
        Node node = (Node) event.getSource();
                        Stage stage = (Stage) node.getScene().getWindow();
                        
                        FXMLLoader loader = new FXMLLoader ();
                            loader.setLocation(getClass().getResource("Statistic.fxml"));
                        try {
                            loader.load();
                           
                           
                              } catch (IOException ex) {
                            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        
                        Parent parent = loader.getRoot();
                        stage.setScene(new Scene(parent));
                        stage.show();
                        
                    }
    
        public void AffichList() {
        
        ServiceNews sn = new ServiceNews();
        
        vBox.setPadding(new Insets(10));
        vBox.setAlignment(Pos.CENTER);

        ObservableList<News> NewsList = sn.AfficherNews();
        listView.setStyle("  -fx-selection-bar: #90ee90 ; -fx-border-color:#90ee90");
        listView.setCellFactory((Callback<ListView<News>, ListCell<News>>) param -> {
            return new ListCell<News>() {
                @Override
                protected void updateItem(News n, boolean empty) {
                    super.updateItem(n, empty);

                    if (n == null || empty) {
                        setText(null);
                    } else {
                       
                        HBox Hbx = new HBox(100);
                        Hbx.setAlignment(Pos.CENTER_LEFT);
                        Hbx.setPadding(new Insets(5, 10, 5, 10));
 Label reacts= new Label(String.valueOf(n.getNbreacts())+" Likes");
                         reacts.setMinWidth(100);
                        reacts.setMinHeight(100);
                        Hbx.getChildren().add(reacts);
                        reacts.setCursor(Cursor.HAND);
   Label ts= new Label(n.getTypeSport());
                         ts.setMinWidth(100);
                        ts.setMinHeight(100);
                        Hbx.getChildren().add(ts);
                        ts.setCursor(Cursor.HAND);
                        //imageNews
                       String path =n.getURLImg();
                                        BufferedImage BfImg = null;
                         try {

                                URL url= new URL(path);
                                BfImg= ImageIO.read(url);
                                
                         } catch (Exception ex) {
                            System.out.println("Failed to load image");
                            System.out.println(ex);
                         }
                         WritableImage wr = null;
                         if (BfImg != null) {
                             wr = new WritableImage(BfImg.getWidth(), BfImg.getHeight());
                             PixelWriter pw = wr.getPixelWriter();
                             for (int x = 0; x < BfImg.getWidth(); x++) {
                                 for (int y = 0; y < BfImg.getHeight(); y++) {
                                     pw.setArgb(x, y, BfImg.getRGB(x, y));
                                 }
                             }
                         }
                         ImageView NewsImage = new ImageView();
                      NewsImage.setFitHeight(300);
                      NewsImage.setFitWidth(500);
                         NewsImage.setImage(wr);
                         Hbx.getChildren().add(NewsImage);
                         
                       Label NewsLabel = new Label(n.getTitre());
                         NewsLabel.setMinWidth(100);
                        NewsLabel.setMinHeight(100);
                        Hbx.getChildren().add(NewsLabel);
                        NewsLabel.setCursor(Cursor.HAND);

                          Label Contenu= new Label(n.getContenu());
                         Contenu.setMinWidth(100);
                        Contenu.setMinHeight(100);
                        Hbx.getChildren().add(Contenu);
                        Contenu.setCursor(Cursor.HAND);
//                        Contenu.setStyle("-fx-text-fill: #90ee90 ;-fx-font-weight: bold;");

                        Region region = new Region();
                        HBox.setHgrow(region, Priority.ALWAYS);
                        Hbx.getChildren().add(region);
                        
                        JFXButton Détails = new JFXButton("Plus de détails");
                        Détails.setStyle("-fx-background-color:  #90ee90; ");
                        
                        Détails.setOnAction(event -> {
                            FXMLLoader loader = new FXMLLoader ();
                            loader.setLocation(getClass().getResource("DetailsActualites.fxml"));
                        try {
                            loader.load();
                           
                              } catch (IOException ex) {
                            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        DetailsActualitesController MUA = loader.getController();
                        MUA.AffichNewsDet2(n);
                        Parent parent = loader.getRoot();
                        Stage stage = new Stage();
                        stage.setScene(new Scene(parent));
                        stage.show();
                           
                        });

                       
Hbx.getChildren().addAll(Détails);
                        setText(null);
                        setGraphic(Hbx);
                    }

                }
            };

        });

        listView.setItems(NewsList);

        vBox.getChildren().add(listView);

       
    }
    
}
    

  
  
  
  


    

    
