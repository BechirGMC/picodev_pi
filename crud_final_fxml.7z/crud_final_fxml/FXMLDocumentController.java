/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crud_version1;

import entite.Participant;
import java.awt.event.MouseEvent;


import serviceclass.Serviceparticipant;

import  java.net.URL;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import java.util.ResourceBundle;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import util.Maconnexion;
import java.util.List;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.scene.control.Alert;
import static javafx.scene.control.cell.ProgressBarTableCell.forTableColumn;
import javafx.scene.control.cell.TextFieldTableCell;
import javax.management.remote.JMXConnectorFactory;
import jdk.nashorn.internal.runtime.Debug;
import static jdk.nashorn.internal.runtime.Debug.id;
import static org.omg.CORBA.AnySeqHelper.id;
import javafx.scene.control.cell.TextFieldTableCell;
import javax.swing.JOptionPane;





/**
 *
 * @author Bechir
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;
    @FXML
    private Button button;
    @FXML
    private TextField tf_nom;
   
    private Label label_affiche;
    @FXML
    private TextField tf_prenom;
    @FXML
    private TableView<Participant> table_participant;
    @FXML
    private TableColumn<Participant, Integer> af_id;
    @FXML
    private TableColumn<Participant, String> af_nom;
    @FXML
    private TableColumn<Participant, String> af_prenom;
    @FXML
    private TextField tf_id;
    @FXML
    private TextField tf_recherche;
    
    
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }
      ObservableList<Participant> listP;
       ObservableList<Participant> DataList;
    int index=-1;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        af_id.setCellValueFactory(new PropertyValueFactory<Participant,Integer>("id"));
af_nom.setCellValueFactory(new PropertyValueFactory<Participant, String>("nom"));
 af_prenom.setCellValueFactory(new PropertyValueFactory<Participant,String>("prenom"));
   listP=Maconnexion.getDataParticipant();
  table_participant.setItems(listP);
     
    }    
    @FXML
    private void ajouter_participant(ActionEvent event) {
        if(valide()){
       Serviceparticipant sp=new Serviceparticipant();
       Participant p=new Participant();
      p.setNom(tf_nom.getText());
         p.setPrenom(tf_prenom.getText());
        sp.ajouter_participant(p);
        updateProduct();
       
        
    }}

    @FXML
    private void affichage_participant(ActionEvent event) {
        
        Serviceparticipant sp=new Serviceparticipant();
        
          label_affiche.setText(sp.affichage_participant().toString());
          
       
}

    @FXML
    private void supprimer_btn(ActionEvent event) {
        ObservableList<Participant> evenements, SingleEvenements;
       evenements=table_participant.getItems();
       SingleEvenements=table_participant.getSelectionModel().getSelectedItems();
  SingleEvenements.forEach(evenements::remove);
        
        
        
    }
    


    @FXML
    private void update_btn(javafx.scene.input.MouseEvent event) {
    }


    @FXML
    private void Select(javafx.scene.input.MouseEvent event) {
  
        
        index =table_participant.getSelectionModel().getSelectedIndex();
        if (index<=-1)
            return;
    
    tf_id.setText(af_id.getCellData(index).toString());
     tf_nom.setText(af_nom.getCellData(index).toString());
       tf_prenom.setText(af_prenom.getCellData(index).toString());
       
         

        
        
    }
    private void updateProduct(){
         af_id.setCellValueFactory(new PropertyValueFactory<Participant,Integer>("id"));
af_nom.setCellValueFactory(new PropertyValueFactory<Participant, String>("nom"));
 af_prenom.setCellValueFactory(new PropertyValueFactory<Participant,String>("prenom"));
   listP=Maconnexion.getDataParticipant();
  table_participant.setItems(listP);
     
    }
    
    
    
    
    
    @FXML
    public void Edit() {
        try{
            String v1=tf_id.getText();
            String v2=tf_nom.getText();
            String v3=  tf_prenom.getText();
            
        
         String req = " update  participant set id= '"+v1+"',nom= '"+v2+"',prenom= '"+
                    v3+"' where id='"+v1+"' ";
PreparedStatement pst=Maconnexion.getInstance().getConnection().prepareStatement(req);
pst.executeUpdate();
updateProduct();
            JOptionPane.showMessageDialog(null, "update");
        }
        catch (SQLException e){
            JOptionPane.showMessageDialog(null, e);
            
        }
        
        
    }

    @FXML
    private void filtrer(ActionEvent event) {
        
        
   af_id.setCellValueFactory(new PropertyValueFactory<Participant,Integer>("id"));
af_nom.setCellValueFactory(new PropertyValueFactory<Participant, String>("nom"));
 af_prenom.setCellValueFactory(new PropertyValueFactory<Participant,String>("prenom"));     
   DataList=Maconnexion.getDataParticipant();
 table_participant.setItems(DataList);
        FilteredList<Participant> filteredDataparticipant=new FilteredList<>(DataList,b->true);
         tf_recherche.textProperty().addListener((observable, oldValue, newValue) -> {
 filteredDataparticipant.setPredicate(Participant -> {
    if (newValue == null || newValue.isEmpty()) {
     return true;
    }    
    String lowerCaseFilter = newValue.toLowerCase();
   
    if (Participant.getNom().toLowerCase().indexOf(lowerCaseFilter) != -1 ) {
     return true; // Filter matches nom
  
    }else if (Participant.getPrenom().toLowerCase().indexOf(lowerCaseFilter) != -1) {
     return true; // Filter matches int
    }   else  
          return false; // Does not match.
   });
  });  
  SortedList<Participant> sortedData = new SortedList<>(filteredDataparticipant);  
  sortedData.comparatorProperty().bind(table_participant.comparatorProperty());  
  table_participant.setItems(sortedData); 


        
        
        
        
        
        
    }
       
    
   private boolean valide()
    {if(tf_nom.getText().isEmpty()|tf_prenom.getText().isEmpty())
    {Alert alert= new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("ajout participant");
        alert.setHeaderText(null);
        alert.setContentText("champ vide!!");
        alert.showAndWait();
    return false;
    }return true ; }

  
    
    
    
    }



