/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crud_version1;

import entite.Match;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javax.swing.JOptionPane;
import serviceclass.Servicematch;
import util.Maconnexion;

/**
 * FXML Controller class
 *
 * @author Bechir
 */
public class MatchController implements Initializable {

    @FXML
    private TextField tf_equipe1;
    @FXML
    private TextField tf_equipe2;
    @FXML
    private TextField tf_date;
    @FXML
    private TextField tf_tour;
    @FXML
    private TextField tf_id;
    @FXML
    private TableView<Match> table_match;
    @FXML
    private TableColumn<Match, Integer> af_id;
    @FXML
    private TableColumn<Match, String> af_equipe1;
    @FXML
    private TableColumn<Match, String> af_equipe2;
    @FXML
    private TableColumn<Match, String> af_date;
    @FXML
    private TableColumn<Match, String> af_tour;
    @FXML
    private TextField tf_recherche;

    /**
     * Initializes the controller class.
     */
    ObservableList<Match> listM;
       ObservableList<Match> DataList;
    int index=-1;
    @FXML
    private Button button;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
         af_id.setCellValueFactory(new PropertyValueFactory<Match,Integer>("id"));
af_equipe1.setCellValueFactory(new PropertyValueFactory<Match, String>("equipeA"));
 af_equipe2.setCellValueFactory(new PropertyValueFactory<Match,String>("equipeB"));
 af_date.setCellValueFactory(new PropertyValueFactory<Match,String>("date"));
  af_tour.setCellValueFactory(new PropertyValueFactory<Match,String>("tour"));
   listM=Maconnexion.getDatamatch();
  table_match.setItems(listM);
     
        
        
        
        
        // TODO
    }    

    @FXML
    private void ajouter_match(ActionEvent event) {
        if(valide()){
       
        Servicematch sp=new Servicematch();
       Match m=new Match();
        
      m.setEquipeA(tf_equipe1.getText());
         m.setEquipeB(tf_equipe2.getText());
          m.setDate(tf_date.getText());
          m.setTour(tf_tour.getText());
        
        sp.ajouter_match(m);
        update();
          
    
        
    }}

    @FXML
    private void afficher_match(ActionEvent event) {
        
         Servicematch sp=new Servicematch();
        
         
        
        
    }

    @FXML
    private void supprimer_match(ActionEvent event) {
         ObservableList<Match> evenements, SingleEvenements;
       evenements=table_match.getItems();
       SingleEvenements=table_match.getSelectionModel().getSelectedItems();
  SingleEvenements.forEach(evenements::remove);    
    }
    
    
   
  
  
    @FXML
   private void filtrer(ActionEvent event) {
        
        
   af_id.setCellValueFactory(new PropertyValueFactory<Match,Integer>("id"));
af_equipe1.setCellValueFactory(new PropertyValueFactory<Match, String>("equipeA"));
 af_equipe2.setCellValueFactory(new PropertyValueFactory<Match,String>("equipeB"));
 af_date.setCellValueFactory(new PropertyValueFactory<Match,String>("date"));
  af_tour.setCellValueFactory(new PropertyValueFactory<Match,String>("tour"));
   DataList=Maconnexion.getDatamatch();
 table_match.setItems(DataList);
        FilteredList<Match> filteredDatamatch=new FilteredList<>(DataList,b->true);
         tf_recherche.textProperty().addListener((observable, oldValue, newValue) -> {
 filteredDatamatch.setPredicate(Match -> {
    if (newValue == null || newValue.isEmpty()) {
     return true;
    }    
    String lowerCaseFilter = newValue.toLowerCase();
   
    if (Match.getEquipeA().toLowerCase().indexOf(lowerCaseFilter) != -1 ) {
     return true; // Filter matches nom
  
    }else if (Match.getEquipeB().toLowerCase().indexOf(lowerCaseFilter) != -1) {
     return true; // Filter matches int
     
    }else if (Match.getDate().toLowerCase().indexOf(lowerCaseFilter) != -1) {
     return true; // Filter matches int
     }else if (Match.getTour().toLowerCase().indexOf(lowerCaseFilter) != -1) {
     return true; // Filter matches int
    }   else  
          return false; // Does not match.
   });
  });  
  SortedList<Match> sortedData = new SortedList<>(filteredDatamatch);  
  sortedData.comparatorProperty().bind(table_match.comparatorProperty());  
  table_match.setItems(sortedData); 


        
       
        
        
    }

       
          private void update(){
         af_id.setCellValueFactory(new PropertyValueFactory<Match,Integer>("id"));
af_equipe1.setCellValueFactory(new PropertyValueFactory<Match, String>("equipeA"));
 af_equipe2.setCellValueFactory(new PropertyValueFactory<Match,String>("equipeB"));
  af_date.setCellValueFactory(new PropertyValueFactory<Match,String>("date"));
   af_tour.setCellValueFactory(new PropertyValueFactory<Match,String>("tour"));
   listM=Maconnexion.getDatamatch();
  table_match.setItems(listM);
     
    }  
        
      @FXML
    private void Select(javafx.scene.input.MouseEvent event) {
  
        
        index =table_match.getSelectionModel().getSelectedIndex();
        if (index<=-1){
            return;
    }
    tf_id.setText(af_id.getCellData(index).toString());
     tf_equipe1.setText(af_equipe1.getCellData(index));
       tf_equipe2.setText(af_equipe2.getCellData(index));
        tf_date.setText(af_date.getCellData(index));
         tf_tour.setText(af_tour.getCellData(index));
       
        
    }   

    @FXML
    private void edit(ActionEvent event) {
        if(valide()){
            try {String v1=tf_id.getText();
           String v2=tf_equipe1.getText();
           String v3=tf_equipe2.getText();
                      String v4=tf_date.getText();
                      String v5=tf_tour.getText();

     String req = "UPDATE `match` set `id`= '"+v1+"',`equipeA`= '"+v2+"',`equipeB`= '"+
                    v3+"',`date`= '"+
                    v4+"',`tour`='"+v5+"' where id= '"+v1+"' ";
PreparedStatement pst=Maconnexion.getInstance().getConnection().prepareStatement(req);
pst.executeUpdate();
               update();
            JOptionPane.showMessageDialog(null, "update");
           } catch (SQLException e) {JOptionPane.showMessageDialog(null, e);
        }}

    }
     private boolean valide()
    {if(tf_equipe1.getText().isEmpty()|tf_equipe2.getText().isEmpty()|tf_tour.getText().isEmpty()|tf_date.getText().isEmpty() )
    {Alert alert= new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("match reconnu");
        alert.setHeaderText(null);
        alert.setContentText("champ vide!!");
        alert.showAndWait();
    return false;
    }return true ; }


        
    
        
    }


  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
    
    
    
    
    
    
    
    
 