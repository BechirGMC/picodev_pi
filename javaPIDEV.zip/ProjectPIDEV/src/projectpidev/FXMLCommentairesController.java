/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectpidev;

import Entities.Commentaire;
import Service.ServiceCommentaires;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.time.Instant;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author guest
 */
public class FXMLCommentairesController implements Initializable {

    @FXML
    private TextArea ContenuCommentaire;
    @FXML
    private Label CommentaireAjouté;
    @FXML
    private Button Valider;
    @FXML
    private Button Annuler;
    @FXML
    private Label nblikes;
    @FXML
    private ImageView Likereact;
    @FXML
    private ImageView SolidarityReact;
    @FXML
    private ImageView WouahReact;
    @FXML
    private Button Supprimer;
    @FXML
    private TextField idtodeletecomment;
    @FXML
    private Button Modifier;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
    }    

    @FXML
    private void ValiderCommentaire(ActionEvent event) {
        ServiceCommentaires sc = new ServiceCommentaires();
        Commentaire c = new Commentaire();
        CommentaireAjouté.setText(ContenuCommentaire.getText());
         c.setContenu(CommentaireAjouté.getText());
         java.util.Date d1 = new java.util.Date();
            Date dateToday = new java.sql.Date(d1.getTime());
         c.setDate_dajout(dateToday);
         
         sc.AjouterCommentaire(c);
         
    }


    int n=0;


    @FXML
    private void AnnulerCommentaire(ActionEvent event) {
    }

   

    @FXML
    private void react1(MouseEvent event) {
         n++;
       nblikes.setText(String.valueOf (n));
    }

    @FXML
    private void react2(MouseEvent event) {
         n++;
       nblikes.setText(String.valueOf (n));
    }

    @FXML
    private void react3(MouseEvent event) {
    
         n++;
       nblikes.setText(String.valueOf (n));

   
        
          
    }

    @FXML
    private void SupprimerCommentaire(ActionEvent event) {
        ServiceCommentaires sc = new ServiceCommentaires();
            Commentaire c = new Commentaire();
       int IDValue = Integer.parseInt(idtodeletecomment.getText());
        c.setId(IDValue);
        sc.SupprimerCommentaire(c);
        
    }
    @FXML
     private void ModifierCommentaire(ActionEvent event) {

    ServiceCommentaires sc = new ServiceCommentaires();
        Commentaire c = new Commentaire();
        c.setContenu(ContenuCommentaire.getText());
         java.util.Date d1 = new java.util.Date();
            Date dateToday = new java.sql.Date(d1.getTime());
         c.setDate_dajout(dateToday);
         int IDValue = Integer.parseInt(idtodeletecomment.getText());
        c.setId(IDValue);
        sc.ModifierCommentaire(c);
     
      
        
    }
    
}

  
    
    

