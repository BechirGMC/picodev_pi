/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectpidev;

import Entities.News;
import Service.ServiceNews;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import static java.util.Collections.list;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.Spinner;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 *
 * @author guest
 */
public class FXMLDocumentController implements Initializable {
    
    private Label label;
    @FXML
    private ComboBox TypeSport;
    @FXML
    private TextArea Titre;
    @FXML
    private TextArea Contenu;
    @FXML
    private Label AffichageDateTitreContenu;
    @FXML
    private TextField idtodeleteupdate;
    @FXML
    private TableView<News> tvNews;
    @FXML
    private TableColumn<News, Integer> ColId;
    @FXML
    private TableColumn<News, String> ColTitre;
    @FXML
    private TableColumn<News, String> ColContenu;
    @FXML
    private TableColumn<News, Date> ColDate;
    @FXML
    private Button Ajout;
    @FXML
    private TableColumn<News, String> ColTypeSport;
    @FXML
    private TextField tfTypeSport;
    @FXML
    private TextField Recherche;
    
  
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
       
       }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
          ObservableList<String> list =FXCollections.observableArrayList
        ("Tennis","Basketball","Football","Volleyball","Baseball","Natation","Rugby");
        
        TypeSport.setItems(list);
                  showNews();  
    }    

    @FXML
    private void AjouterNews(ActionEvent event) {
        ServiceNews sn= new ServiceNews();
        News n = new News();
//        n.setDate(java.sql.Date.valueOf(date.getValue()));
    java.util.Date d1 = new java.util.Date();
            java.sql.Date dateToday = new java.sql.Date(d1.getTime());
         n.setDate(dateToday);
      n.setTitre(Titre.getText());
        n.setContenu(Contenu.getText());
        n.setTypeSport(tfTypeSport.getText());
        sn.AjouterNews(n);
         showNews(); 
    }
    @FXML
    private void AfficherNews(ActionEvent event) throws IOException {

                ServiceNews sn= new ServiceNews();
                 showNews(); 
        
    }

    @FXML
    
    private void SupprimerNews(ActionEvent event) {
        
         ServiceNews sn= new ServiceNews();
        News n = new News();
        int IDValue = Integer.parseInt(idtodeleteupdate.getText());
        n.setId(IDValue);
        sn.SupprimerNews(n);
        showNews(); 
        
    }
       
    @FXML
    private void ModifierNews(ActionEvent event) {

    ServiceNews sn= new ServiceNews();
        News n = new News();
//        n.setDate(java.sql.Date.valueOf(date.getValue()));
            java.util.Date d1 = new java.util.Date();
            java.sql.Date dateToday = new java.sql.Date(d1.getTime());
         n.setDate(dateToday);
      n.setTitre(Titre.getText());
        n.setContenu(Contenu.getText());
        int IDValue = Integer.parseInt(idtodeleteupdate.getText());
        n.setId(IDValue);
        n.setTypeSport(tfTypeSport.getText());
        sn.ModifierNews(n);
         showNews(); 
        
        
    }
    public void showNews(){
        ServiceNews sn = new ServiceNews();
        ObservableList<News> listNews = sn.AfficherNews();
        ColId.setCellValueFactory(new PropertyValueFactory<News, Integer>("id") );
       ColTitre.setCellValueFactory(new PropertyValueFactory<News, String>("Titre") );
       ColContenu.setCellValueFactory(new PropertyValueFactory<News, String>("Contenu") );
       ColDate.setCellValueFactory(new PropertyValueFactory<News, Date>("date") );
      ColTypeSport.setCellValueFactory(new PropertyValueFactory<News, String>("TypeSport"));
       tvNews.setItems(listNews);

        
    }
    

    @FXML
    private void AffichageTextfields(MouseEvent event) throws IOException {
        
            News n =tvNews.getSelectionModel().getSelectedItem();
            Titre.setText(n.getTitre());
            Contenu.setText(n.getContenu());
            tfTypeSport.setText(n.getTypeSport());
            String s = String.valueOf(n.getId());
            idtodeleteupdate.setText(s);
          FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXMLCommentaires.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root1));  
            stage.show();
        

}

    @FXML
    private void SelectTypeSport(ActionEvent event) {
      String s =TypeSport.getSelectionModel().getSelectedItem().toString();
      tfTypeSport.setText(s);
      
    }

    
}
